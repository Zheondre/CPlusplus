/**********************************************************************
 *  readme.txt template                                                   
 *  Plucking a Guitar String
 **********************************************************************/

Name: Angel Calcano
CS Login: acalcano


Hours to complete assignment (optional):
25 hours 

/**********************************************************************
 *  Did you complete the whole assignment?
 *  Successfully or not? 
 *  Indicate which parts you think are working, and describe
 *    how you know that they're working.
 **********************************************************************/
I kept getting an error in the boost test, when I commented out the test 
every thing worked until the last line of the test. ALso when I run my code 
I dont get any sound. I think I had almost every thing working due to the 
fact when I commented out that one boost test it passed most of the others.
When I tried putting print statementes in the code it fails right after the last enqueue. 

/**********************************************************************
 *  Did you attempt the extra credit parts? Which one(s)?
 *  Successfully or not?  As a pair, or individually?
 *  If you completed the AutoGuitar, what does it play?
 **********************************************************************/
I couldn't since I spent alot of time debugging. 

/**********************************************************************
 *  Does your GuitarString implementation pass the unit tests?
 *  Indicate yes or no, and explain how you know that it does or does not.
 **********************************************************************/

If the first test is commented out it will pass the rest expcet the last test.
I tried putting print statments in the code while I run the first test and the program segfaults after placing all the values in the string buffer.

/**********************************************************************
 *  List whatever help (if any) you received from lab TAs,
 *  classmates, or anyone else.
 **********************************************************************/
Got help looking at the lecture capture trying to figure out how to catch the button being pressed.


/**********************************************************************
 *  Describe any serious problems you encountered.                    
 **********************************************************************/
Trying to figure out why the first test failed.


/**********************************************************************
 *  List any other comments here.                                     
 **********************************************************************/


