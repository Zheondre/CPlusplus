/**********************************************************************
 *  ps1-readme template
 *  Sierpinski Assignment
 **********************************************************************/

Name: Angel Zheondre Calcano

/********** Implementation **********************/ 

I made a math algorithm for sierpinski to find the lowest midpoint of the current triangle. Once it is found find the two points that is found from side*sin(60)
and side*cos(60). Once that is found pass the location of the mid points of the three smaller triangles into three other function calls. 

For the second program I used a similar method. But I did the design based on 120 degrees, instead of 60 degrees. Only thing hard about it was trying to figure out why I kept getting zero when I casted a value as a double or an int. Too much time was spent on debuging. What was annoying was that I had to specify the origin of each circle when I set the position for that shape. If not specified it would be set to 0,0. I didn't use any data structures and I specified the frames to be set to one. 

 
Hours to complete assignment (optional):
About 20, Most of the time was spent on debugging: Had a lot of math
errors. Had issues with using sin() and cos(). 


/**********************************************************************
 *  List whatever help (if any) you received from TAs, the instructor,
 *  classmates, or anyone else.
 **********************************************************************/
Didn't need any help. 


/**********************************************************************
 *  Describe any serious problems you encountered.                    
 **********************************************************************/
Casting kept making my values go to zero for some strange reason. 


/**********************************************************************
 *  List any other comments here.                                     
 **********************************************************************/

