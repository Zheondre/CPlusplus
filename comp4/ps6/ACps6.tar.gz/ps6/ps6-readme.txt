/**********************************************************************
 *  readme.txt template                                                   
 *  Markov Model
 **********************************************************************/

Name: Angel Zheondre Calcano


Hours to complete assignment (optional):
20

/**********************************************************************
 *  Did you complete the whole assignment?
 *  Successfully or not? 
 *  Indicate which parts you think are working, and describe
 *    how you know that they're working.
 **********************************************************************/
Yes, since the code passed all the boost tests



/**********************************************************************
 *  Did you attempt the extra credit parts? Which one(s)?
 *  Successfully or not?  
 **********************************************************************/
No


/**********************************************************************
 *  Does your implementation pass the unit tests?
 *  Indicate yes or no, and explain how you know that it does or does not.
 **********************************************************************/
Yes, I know it passed because there weren't any errors reported.



/**********************************************************************
 *  List whatever help (if any) you received from lab TAs,
 *  classmates, or anyone else.
 **********************************************************************/
None, only used the given header file from the website.


/**********************************************************************
 *  Describe any serious problems you encountered.                    
 **********************************************************************/

Major problem was trying to keep every thing organized. I kept getting alot of 
errors but evebtually I got it working. 

/**********************************************************************
 *  List any other comments here.                                     
 **********************************************************************/


