/**********************************************************************
 *  ps2a-readme template                                                   
 *  LFSR Assignment                       
 **********************************************************************/

Name: Angel Zheondre Calcano


Hours to complete assignment (optional):
About 15 due to an old version of compiler it kept giving me errors about functions I was using to operate the code, these functions are usable in c++11


/**********************************************************************
 *  List whatever help (if any) you received from TAs, the instructor,
 *  classmates, or anyone else.
 **********************************************************************/
Didn't need any help. 


/**********************************************************************
 *  Describe any serious problems you encountered.                    
 **********************************************************************/
Overloading the << operator 


/**********************************************************************
 *  List any other comments here.                                     
 **********************************************************************/

