/**********************************************************************
 * Ps2a 
 * readme.txt                                                   
 * Psx 
 **********************************************************************/

Name:Angel Calcano

Hours to complete assignment (optional): about 2

I added the test cases for boost, in the original hw I didn't have it, I also made a readmefile, I 
also edited the code to follow the google style guide. I made a test to catch an additional error 
to see if the boost library will see it and it did. It found an error on lines 15 in the orignal test case
and the additional error I placed in was at line 49.  



