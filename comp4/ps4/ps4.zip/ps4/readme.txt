/**********************************************************************
 *  ps-readme template                                                   
 *  Hello World Assignment                       
 **********************************************************************/

Name: Angel Zheondre Calcano


Hours to complete assignment (optional):
About 20, Most of the time was spent on debugging: Had alot of math
errors. Had issues with using sin() and cos(). 


/**********************************************************************
 *  List whatever help (if any) you received from TAs, the instructor,
 *  classmates, or anyone else.
 **********************************************************************/
Didn't need any help. 


/**********************************************************************
 *  Describe any serious problems you encountered.                    
 **********************************************************************/
Casting kept making my values go to zero for some strange reason 


/**********************************************************************
 *  List any other comments here.                                     
 **********************************************************************/

